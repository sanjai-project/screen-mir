#!/usr/bin/env python3
"""Laptop Mirror: laptop screen -> Android phone over USB, with touch control. Run: python laptop_app.py"""
import ctypes, os, platform, queue, shutil, socket, struct, subprocess, sys, threading, time
import tkinter as tk
from tkinter import ttk

OS = platform.system()
PHONE_PORT = 5555        # port the Screen Mirror app listens on (Receive screen)
LOCAL_PORT = 7777
NOWIN = 0x08000000 if OS == "Windows" else 0   # hide console windows of adb/ffmpeg
QUALITY = {"Fast (low lag)": (60, 8, 1280), "Balanced": (60, 15, 1920), "Sharp": (60, 25, 1920)}

def base_dir():
    return os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))

def tool(name):
    exe = name + (".exe" if OS == "Windows" else "")
    for d in (os.path.join(base_dir(), "bin"), base_dir()):
        p = os.path.join(d, exe)
        if os.path.isfile(p): return p
    return shutil.which(name)

def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, creationflags=NOWIN)

def screen_size():
    if OS == "Windows":
        try: ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try: ctypes.windll.user32.SetProcessDPIAware()
            except Exception: pass
    import pyautogui
    s = pyautogui.size()
    return s.width, s.height

def test_encoder(ff, enc):
    r = run([ff, "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=black:s=256x256:d=0.2",
             "-c:v", enc, "-f", "null", "-"])
    return r.returncode == 0

def pick_encoder(ff):
    out = run([ff, "-hide_banner", "-encoders"]).stdout
    order = {"Windows": ["h264_nvenc", "h264_qsv", "h264_amf"], "Darwin": ["h264_videotoolbox"],
             "Linux": ["h264_nvenc"]}.get(OS, [])
    for e in order:
        if e in out and test_encoder(ff, e): return e
    return "libx264"

def ffmpeg_cmd(ff, enc, W, H, oW, oH, fps, kbps):
    if OS == "Windows":
        src = ["-f", "gdigrab", "-framerate", str(fps), "-draw_mouse", "1", "-offset_x", "0", "-offset_y", "0",
               "-video_size", f"{W}x{H}", "-i", "desktop"]
    elif OS == "Darwin":
        src = ["-f", "avfoundation", "-framerate", str(fps), "-capture_cursor", "1", "-i", "1:none"]
    else:
        src = ["-f", "x11grab", "-framerate", str(fps), "-draw_mouse", "1", "-video_size", f"{W}x{H}",
               "-i", os.environ.get("DISPLAY", ":0.0")]
    c = [ff, "-hide_banner", "-loglevel", "error", "-fflags", "nobuffer", "-flags", "low_delay"] + src
    c += ["-vf", f"scale={oW}:{oH}:flags=fast_bilinear,format=yuv420p"]
    g = str(fps)
    if enc == "libx264":
        c += ["-c:v", "libx264", "-preset", "ultrafast", "-tune", "zerolatency", "-bf", "0", "-g", g,
              "-b:v", f"{kbps}k", "-maxrate", f"{kbps}k", "-bufsize", f"{max(kbps // fps, 100)}k"]
    elif enc == "h264_nvenc":
        c += ["-c:v", enc, "-preset", "p1", "-tune", "ull", "-zerolatency", "1", "-bf", "0", "-g", g,
              "-rc", "cbr", "-b:v", f"{kbps}k", "-forced-idr", "1"]
    elif enc == "h264_qsv":
        c += ["-c:v", enc, "-preset", "veryfast", "-bf", "0", "-g", g, "-b:v", f"{kbps}k", "-look_ahead", "0"]
    elif enc == "h264_amf":
        c += ["-c:v", enc, "-usage", "ultralowlatency", "-bf", "0", "-g", g, "-b:v", f"{kbps}k"]
    else:
        c += ["-c:v", enc, "-b:v", f"{kbps}k", "-g", g]
    c += ["-bsf:v", "dump_extra=freq=keyframe,h264_metadata=aud=insert", "-flush_packets", "1", "-f", "h264", "-"]
    return c

def split_units(stream):
    """Yield access units; each starts with an AUD NAL (type 9)."""
    buf = b""
    while True:
        chunk = os.read(stream.fileno(), 1 << 16)
        if not chunk: return
        buf += chunk
        starts, i = [], 0
        while True:
            i = buf.find(b"\x00\x00\x01", i)
            if i < 0 or i + 3 >= len(buf): break
            if (buf[i + 3] & 0x1F) == 9:
                starts.append(i - 1 if i > 0 and buf[i - 1] == 0 else i)
            i += 3
        if len(starts) >= 2:
            for a, b in zip(starts, starts[1:]): yield buf[a:b]
            buf = buf[starts[-1]:]

def has_idr(au):
    i = 0
    while True:
        i = au.find(b"\x00\x00\x01", i)
        if i < 0 or i + 3 >= len(au): return False
        if (au[i + 3] & 0x1F) == 5: return True
        i += 3

class Session:
    def __init__(self, quality, touch, log, status):
        self.fps, self.mbps, self.maxw = QUALITY[quality]
        self.touch, self.log, self.status = touch, log, status
        self.stop_ev = threading.Event()
        self.proc = None
        self.sock = None

    def stop(self):
        self.stop_ev.set()
        for f in (lambda: self.proc.kill(), lambda: self.sock.close()):
            try: f()
            except Exception: pass

    def run(self):
        try: self._run()
        except Exception as e: self.log(f"Error: {e}"); self.status("Error")
        self.status("Stopped")

    def _run(self):
        adb, ff = tool("adb"), tool("ffmpeg")
        if not adb or not ff:
            self.log("adb or ffmpeg missing. Put them in a 'bin' folder next to this app (or on PATH).")
            return
        try: import pyautogui  # noqa
        except ImportError: self.log("Missing pyautogui: pip install pyautogui"); return
        W, H = screen_size()
        oW = min(self.maxw, W) // 2 * 2
        oH = int(H * oW / W) // 2 * 2
        self.log("Choosing encoder..."); enc = pick_encoder(ff)
        self.log(f"Screen {W}x{H} -> {oW}x{oH} @ {self.fps}fps, encoder {enc}")
        while not self.stop_ev.is_set():
            self.status("Plug in the phone (USB debugging ON)")
            devs = [l for l in run([adb, "devices"]).stdout.splitlines()[1:] if l.strip().endswith("\tdevice")]
            if not devs:
                run([adb, "start-server"]); time.sleep(1); continue
            run([adb, "forward", f"tcp:{LOCAL_PORT}", f"tcp:{PHONE_PORT}"])
            self.status("Open Screen Mirror on the phone > Receive")
            s = self._connect()
            if s is None: time.sleep(1); continue
            self.sock = s
            self.status("Mirroring")
            self.log("Phone connected.")
            self._stream(ff, enc, W, H, oW, oH)
            if not self.stop_ev.is_set(): self.log("Phone disconnected. Waiting again...")
        run([adb, "forward", "--remove", f"tcp:{LOCAL_PORT}"])

    def _connect(self):
        try:
            s = socket.create_connection(("127.0.0.1", LOCAL_PORT), timeout=3)
            s.settimeout(1.0)
            try:
                if s.recv(1, socket.MSG_PEEK) == b"": s.close(); return None   # phone not listening yet
            except socket.timeout: pass
            s.settimeout(None)
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            return s
        except OSError: return None

    def _touch(self, s, W, H):
        import pyautogui
        pyautogui.PAUSE = 0; pyautogui.FAILSAFE = False
        down, f = False, s.makefile("rb")
        try:
            while True:
                b = f.read(12)
                if not b or len(b) < 12: return
                a, x, y = struct.unpack(">iff", b)
                px, py = int(x * (W - 1)), int(y * (H - 1))
                if a == 0: pyautogui.moveTo(px, py); pyautogui.mouseDown(); down = True
                elif a == 2 and down: pyautogui.moveTo(px, py)
                elif a == 1: pyautogui.moveTo(px, py); pyautogui.mouseUp(); down = False
        except Exception: return

    def _stream(self, ff, enc, W, H, oW, oH):
        s = self.sock
        try: s.sendall(struct.pack(">biiii", 2, 0, 8, oW, oH))     # type 2 = video size
        except OSError: return
        if self.touch: threading.Thread(target=self._touch, args=(s, W, H), daemon=True).start()
        self.proc = p = subprocess.Popen(ffmpeg_cmd(ff, enc, W, H, oW, oH, self.fps, int(self.mbps * 1000)),
                                         stdout=subprocess.PIPE, creationflags=NOWIN)
        q = queue.Queue(maxsize=4)
        dead = threading.Event()
        def sender():
            try:
                while not dead.is_set():
                    try: au, key = q.get(timeout=0.5)
                    except queue.Empty: continue
                    s.sendall(struct.pack(">bii", 0, 1 if key else 0, len(au)) + au)
            except OSError: pass
            dead.set()
            try: p.kill()
            except Exception: pass
        threading.Thread(target=sender, daemon=True).start()
        need_key = False
        try:
            for au in split_units(p.stdout):
                if dead.is_set() or self.stop_ev.is_set(): break
                key = has_idr(au)
                if need_key and not key: continue       # after a drop, wait for a keyframe (never builds lag)
                need_key = False
                try: q.put_nowait((au, key))
                except queue.Full: need_key = True
        except Exception: pass
        dead.set()
        try: p.kill()
        except Exception: pass
        try: s.close()
        except Exception: pass

class App:
    def __init__(self, root):
        self.root = root; self.sess = None
        root.title("Laptop Mirror"); root.geometry("460x440"); root.configure(bg="#10131a")
        st = ttk.Style(); st.theme_use("clam")
        st.configure("TLabel", background="#10131a", foreground="#e8ecf4")
        st.configure("TCheckbutton", background="#10131a", foreground="#e8ecf4")
        tk.Label(root, text="Laptop Mirror", font=("Segoe UI", 22, "bold"), bg="#10131a", fg="#ffffff").pack(pady=(16, 0))
        tk.Label(root, text="Laptop screen on your phone over USB, with touch", bg="#10131a", fg="#9aa4b8").pack()
        self.state = tk.Label(root, text="Stopped", font=("Segoe UI", 12, "bold"), bg="#10131a", fg="#7cc4ff")
        self.state.pack(pady=10)
        row = tk.Frame(root, bg="#10131a"); row.pack()
        ttk.Label(row, text="Quality").pack(side="left", padx=6)
        self.q = tk.StringVar(value="Balanced")
        ttk.Combobox(row, textvariable=self.q, values=list(QUALITY), state="readonly", width=16).pack(side="left")
        self.touch = tk.BooleanVar(value=True)
        ttk.Checkbutton(root, text="Phone touch controls this laptop", variable=self.touch).pack(pady=6)
        self.btn = tk.Button(root, text="START", font=("Segoe UI", 16, "bold"), bg="#2f81f7", fg="white",
                             activebackground="#1f6feb", relief="flat", height=2, width=18, command=self.toggle)
        self.btn.pack(pady=8)
        tk.Label(root, text="Phone: USB debugging ON, cable plugged, app Screen Mirror > Receive",
                 bg="#10131a", fg="#9aa4b8", wraplength=420).pack()
        self.box = tk.Text(root, height=8, bg="#0b0d12", fg="#c9d1d9", relief="flat", state="disabled")
        self.box.pack(fill="both", expand=True, padx=12, pady=10)
        root.protocol("WM_DELETE_WINDOW", self.close)

    def log(self, t):
        def f():
            self.box.config(state="normal"); self.box.insert("end", t + "\n"); self.box.see("end")
            self.box.config(state="disabled")
        self.root.after(0, f)

    def status(self, t):
        self.root.after(0, lambda: self.state.config(text=t))

    def toggle(self):
        if self.sess:
            self.sess.stop(); self.sess = None; self.btn.config(text="START", bg="#2f81f7")
        else:
            self.sess = Session(self.q.get(), self.touch.get(), self.log, self.status)
            threading.Thread(target=self.sess.run, daemon=True).start()
            self.btn.config(text="STOP", bg="#da3633")

    def close(self):
        if self.sess: self.sess.stop()
        self.root.destroy()

if __name__ == "__main__":
    r = tk.Tk(); App(r); r.mainloop()
